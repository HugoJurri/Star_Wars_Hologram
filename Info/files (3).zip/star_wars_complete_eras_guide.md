# The Complete Star Wars Timeline — A Comprehensive Guide to Every Era and Event

A definitive overview of the major eras of the Star Wars galaxy, from the dawn of the Jedi through the rise of a new generation, spanning roughly 36,000 years of in-universe history.

---

## Part I: Foundational Concepts

Before diving into the eras themselves, it's essential to understand the framework that organizes Star Wars history.

### 1.1 The Dating System: BBY and ABY

All of Star Wars history is measured against a single anchor point: **the Battle of Yavin**, which is the climactic battle at the end of *A New Hope* (Episode IV), where Luke Skywalker destroyed the first Death Star.

- **BBY (Before the Battle of Yavin):** Events that occurred before the destruction of the first Death Star. Higher numbers = further in the past. The Clone Wars began in 22 BBY. The High Republic existed roughly 500–100 BBY.
- **ABY (After the Battle of Yavin):** Events that occurred after. The Battle of Endor (Return of the Jedi) was in 4 ABY. The Battle of Exegol (Rise of Skywalker) was in 35 ABY.
- **0 BBY/ABY:** The Battle of Yavin itself — the inflection point of galactic history.

This system is similar to the BCE/CE (or BC/AD) system used in real-world history, just with a different anchor point. In-universe, characters use other dating systems (the Galactic Standard Calendar tied to the Republic's founding), but BBY/ABY is the convention used by fans and most reference material.

### 1.2 Canon vs. Legends

Star Wars has two parallel storytelling continuities:

**Canon (officially canonical, post-2014):**
When Disney acquired Lucasfilm in 2012, they reorganized Star Wars storytelling. In April 2014, they declared that going forward, only the following would be considered official Star Wars canon:
- The nine episodic films (Episodes I–IX)
- The anthology films (*Rogue One*, *Solo*)
- *The Clone Wars* TV series and film
- *Star Wars Rebels*
- All Disney-era films, TV series (*The Mandalorian*, *Andor*, *Ahsoka*, *The Book of Boba Fett*, etc.)
- New novels, comics, and games released from 2014 onward
- The High Republic multimedia initiative

**Legends (the former Expanded Universe, pre-2014):**
Everything published before April 2014 outside the films and *The Clone Wars* — thousands of novels, comics, video games, and reference books — was rebranded as "Star Wars Legends." This includes:
- The Thrawn Trilogy (Timothy Zahn) — though Thrawn was reintroduced into canon via *Rebels* and *Ahsoka*
- *Knights of the Old Republic* games and comics
- The Old Republic MMORPG
- The New Jedi Order book series
- The Legacy comics
- And much more

**Why this matters:** Legends contains an enormous amount of beloved material that is no longer "official" but remains foundational to fan culture. Many concepts have been reintegrated into canon (Thrawn, the Inquisitorius, some lore), but many haven't (Mara Jade, Jaina and Jacen Solo, the post-Endor Yuuzhan Vong War, the ancient Sith characters from KOTOR). This guide focuses primarily on canon while noting key Legends material where it provides important context.

### 1.3 Sources of Star Wars Storytelling

The Star Wars saga is told across multiple media:
- **Films:** The 11 theatrical releases (9 saga films, 2 anthology films)
- **Animated series:** *The Clone Wars*, *Rebels*, *Resistance*, *The Bad Batch*, *Tales of the Jedi*, *Tales of the Empire*, *Visions*, *Young Jedi Adventures*
- **Live-action series:** *The Mandalorian*, *The Book of Boba Fett*, *Andor*, *Obi-Wan Kenobi*, *Ahsoka*, *Skeleton Crew*
- **Novels and comics:** Hundreds of works covering every era
- **Video games:** *Jedi: Fallen Order*, *Jedi: Survivor*, *Squadrons*, *Battlefront*, and others
- **The High Republic Initiative:** A multimedia publishing project (novels, comics, junior fiction) exploring the era ~200 years before the prequels

---

## Part II: The Major Eras

### Era 1: The Dawn of the Jedi (~36,000 BBY – ~25,000 BBY)

**Overview:**
The earliest era of recorded galactic history, predating the Galactic Republic itself. This is the murky pre-history where the Force was first studied and the foundations of the Jedi Order were laid. Much of this period exists in shadow — even in-universe, records from this time are fragmentary, mythic, and contested.

**Key Concepts and Events:**

- **The first awakening of Force traditions:** Various species across the galaxy independently discovered the Force and developed their own philosophies and practices. Force-sensitive communities arose on multiple worlds.
- **The Prime Jedi and Ahch-To:** According to canon, the first Jedi Temple was established on the remote ocean world of **Ahch-To**, where the "Prime Jedi" meditated on the balance between light and dark. The mosaic of the Prime Jedi seen in *The Last Jedi* depicts this founding figure — a meditating being balanced between light and dark, suggesting that the original Jedi philosophy was one of harmony rather than strict opposition.
- **The Ones of Mortis:** A trio of god-like Force wielders — the Father, the Daughter, and the Son — who embodied balance, light, and dark respectively. They existed on a mysterious world called Mortis in a realm between dimensions. Their story (told in *The Clone Wars*) suggests that the Force itself has personified manifestations beyond mortal Force users.
- **The Sith Pure-bloods (Legends primarily):** The original Sith species — red-skinned, tattooed humanoids native to the planet **Korriban** (renamed Moraband in canon). They had their own Force-based civilization long before the term "Sith" came to mean dark-side users.
- **Foundation of the Jedi Order:** Over millennia, scattered Force traditions gradually consolidated. The Jedi Order as a formal institution emerged sometime in this deep past, dedicating itself to the light side of the Force.

**Why This Era Matters:**
This era is largely background lore, but it establishes the cosmic-mythological foundation of the saga. The Force is not a recent discovery — it has been studied and practiced for tens of thousands of years before the events we see on screen.

---

### Era 2: The Old Republic Era (~25,000 BBY – ~1,000 BBY)

**Overview:**
A vast, sprawling period of roughly 24,000 years during which the Galactic Republic was founded, expanded, and fought a series of cataclysmic wars against the Sith. This era is dominated by the great Sith-Jedi conflicts — wars so massive they reshaped the galaxy multiple times. Most of this era is covered in the Legends continuity (now non-canonical), particularly through the *Knights of the Old Republic* games and novels, though canon has begun filling in fragments.

**Key Events and Periods:**

**The Founding of the Galactic Republic (~25,000 BBY):**
- The Galactic Republic is established on Coruscant as a democratic union of worlds connected by the newly opened hyperspace lanes.
- The Jedi Order formally allies with the Republic, becoming its peacekeepers and guardians.

**The Hundred-Year Darkness (~7,000 BBY, Legends):**
- A schism within the Jedi Order. A group of Jedi began experimenting with the dark side, creating monstrous Force-twisted creatures and pursuing forbidden knowledge. After a century of conflict, they were defeated and exiled by the Jedi Order.
- The exiles fled to the Outer Rim, eventually arriving on **Korriban**, where they encountered the native Sith species. The exiled dark Jedi conquered and subjugated the Sith, and over generations the two peoples interbred and merged. The term "Sith" came to refer not just to the species but to the dark-side tradition they founded.

**The Great Hyperspace War (~5,000 BBY, Legends):**
- The Sith Empire, having grown in secret for thousands of years, launched a surprise invasion of the Republic. The war was brief but devastating. The Republic and the Jedi ultimately repelled the Sith, who retreated to their hidden territories.

**The Great Sith War / The Mandalorian Wars / The Jedi Civil War (~4,000 BBY, Legends — *Knights of the Old Republic* era):**
- A complex series of overlapping conflicts. The Mandalorians launched a campaign of conquest against the Republic. The Jedi were divided over whether to intervene. A faction led by **Revan** and **Malak** went to war against the Mandalorians, defeated them, but discovered the Sith Empire in the Unknown Regions and fell to the dark side themselves.
- Revan returned as a Sith Lord and waged war against the Republic, then was captured and redeemed. This story (told in *Knights of the Old Republic*) is one of the most beloved in Star Wars Legends.
- Revan was later reintroduced as a canonical figure in passing references, but the full KOTOR storyline remains Legends.

**The Great Galactic War / The Old Republic Era (~3,600 BBY, Legends — *The Old Republic* MMORPG era):**
- Another reconstituted Sith Empire attacked the Republic. A long cold war and series of conflicts followed.
- This era features prominently in the *Star Wars: The Old Republic* MMO and associated media.

**The New Sith Wars (~2,000–1,000 BBY, Legends):**
- A thousand-year period of nearly continuous warfare between the Republic/Jedi and various Sith factions.
- The Sith were ultimately defeated at the **Seventh Battle of Ruusan** (1,000 BBY), where the Jedi Master Hoth led an army of Jedi against the Sith Brotherhood of Darkness led by Lord Kaan. Kaan detonated a "thought bomb" that wiped out nearly every Sith and Jedi present.

**The Establishment of the Rule of Two (~1,000 BBY):**
- One Sith survived Ruusan: **Darth Bane**. He concluded that the Sith's downfall had always been their numbers — they destroyed themselves through internal warfare and treachery. He established the **Rule of Two**: there would only ever be two Sith at any one time, a master and an apprentice. "One to embody the power, one to crave it." When the apprentice grew strong enough, they would kill the master and take their own apprentice.
- Bane's rule allowed the Sith to operate in absolute secrecy for the next millennium, plotting their revenge. This is the lineage that culminates in Darth Sidious and the fall of the Republic.

**The Ruusan Reformation:**
- After the destruction of the Sith at Ruusan, the Republic underwent major reforms. The Jedi disarmed (giving up their military forces). The Republic became more decentralized. A thousand years of relative peace followed — though the Republic gradually became complacent, bureaucratic, and corrupt during this golden age.

---

### Era 3: The High Republic (~500 BBY – ~100 BBY)

**Overview:**
The High Republic is the **golden age of the Jedi Order and the Galactic Republic**. This era was largely uncharted territory until Disney/Lucasfilm launched **The High Republic** multimedia publishing initiative in 2021. It is now one of the richest periods of canon storytelling. The High Republic Jedi are at the height of their power, numbers, and idealism — adventurer-knights operating from grand "Starlight Beacon" space stations on the galactic frontier.

**Key Concepts and Events:**

**The Era's Character:**
- The Republic is expanding outward into the **Outer Rim**, opening new hyperspace routes and welcoming new member worlds.
- The Jedi number in the tens of thousands and are stationed across the galaxy in **Jedi Outposts and Temples**, not concentrated on Coruscant as they would be in the prequel era.
- The aesthetic is more medieval/classical — Jedi wear ornate robes, capes, and tabards. The era feels like a high-fantasy chivalric age, deliberately distinct from the dustier prequel period.

**The Great Disaster (~232 BBY):**
- A catastrophic hyperspace accident: a Legacy Run colony vessel was destroyed mid-jump, and its debris scattered across the galaxy at faster-than-light speeds — causing devastation across multiple star systems as wreckage emerged from hyperspace at random locations.
- The Republic and the Jedi led a massive rescue and recovery effort.

**The Emergence of the Nihil:**
- The **Nihil** were a chaotic, anarchic pirate confederation operating in the Outer Rim. Led by the cunning and ruthless **Marchion Ro**, they possessed a stolen secret — the ability to make uncharted, dangerous "Paths" through hyperspace using a Force-suppressing creature called the **Nameless** (or "Levelers").
- The Nameless were ancient horrors capable of consuming a Jedi's connection to the Force — physically aging and destroying them. They represented the High Republic's most terrifying threat: an enemy specifically deadly to Jedi.

**The Starlight Beacon:**
- A massive space station and Jedi/Republic outpost in the Outer Rim — a symbol of Republic expansion and Jedi presence on the frontier. It served as both a beacon of civilization and a strategic command center.
- It was eventually destroyed by the Nihil in a devastating attack that killed many Jedi and civilians — a turning point in the High Republic era.

**Notable High Republic Jedi:**
- **Avar Kriss** — The "Marshal of Starlight," a legendary Jedi who could perceive the Force as a song connecting all life.
- **Stellan Gios** — A council member and master strategist.
- **Elzar Mann** — A passionate, flawed Jedi who struggled with attachment.
- **Bell Zettifar** — A young Padawan who featured prominently in early High Republic stories.
- **Yoda** — Yes, Yoda was already an active Jedi Master during the High Republic. He appears in multiple High Republic stories, already centuries old.
- **Reath Silas, Vernestra Rwoh, Cohmac Vitus** — Featured in the Young Adult and Junior Fiction lines.

**The Nihil War (200–232 BBY):**
- A multi-year conflict between the Republic/Jedi and the Nihil. The war ended with the Nihil's defeat, but at enormous cost — Starlight Beacon's destruction, the deaths of many Jedi, and the first deployments of the Nameless.

**Tales of the Jedi:**
- Disney's animated series *Tales of the Jedi* (2022) features a young Count Dooku and his master Yaddle during the late High Republic — bridging the era to the prequel period.

**Why This Era Matters:**
The High Republic represents the Jedi at their best — confident, adventurous, idealistic, and respected across the galaxy. It also plants the seeds of their later vulnerabilities: institutional confidence verging on arrogance, doctrinal rigidity around attachment, and a faith in the Republic that would prove fatally misplaced.

---

### Era 4: The Fall of the Jedi / Prequel Era (~100 BBY – 19 BBY)

**Overview:**
This is the era of the prequel trilogy and *The Clone Wars*. It chronicles the slow decay of the Galactic Republic, the rise of Palpatine, the engineering of a civil war, and the systematic destruction of the Jedi Order. Roughly a century of decline culminates in the most dramatic transformation in galactic history: the Republic becoming the Empire.

**Key Concepts and Events:**

**Pre-Phantom Menace Background:**
- The Republic has been at peace for nearly a thousand years (since the Ruusan Reformation). Bureaucracy, corruption, and complacency have set in.
- The Sith, hidden under the Rule of Two, have been preparing their revenge for a thousand years. The lineage that culminates in Palpatine spans many generations of Sith Lords.
- **Darth Plagueis the Wise** — A Muun Sith Lord who became obsessed with the manipulation of midi-chlorians to create life and prevent death. He took Sheev Palpatine of Naboo as his apprentice. According to Palpatine's own legend (told to Anakin), Plagueis succeeded in creating life from midi-chlorians but couldn't save himself — Palpatine murdered him in his sleep. This story heavily implies that Anakin Skywalker himself, conceived without a father, may have been the result of Plagueis's midi-chlorian manipulation.

**The Invasion of Naboo / The Phantom Menace (32 BBY):**
- The Trade Federation, secretly manipulated by Darth Sidious (Palpatine), blockades and invades the peaceful planet of Naboo over a manufactured trade dispute.
- Jedi Master **Qui-Gon Jinn** and his apprentice **Obi-Wan Kenobi** are sent as Republic ambassadors. They escape the blockade with Queen **Padmé Amidala** and crash-land on **Tatooine**.
- On Tatooine, Qui-Gon discovers a young slave boy with no father: **Anakin Skywalker**. His midi-chlorian count is the highest ever recorded — Qui-Gon believes Anakin is the **Chosen One** of Jedi prophecy, destined to bring balance to the Force.
- Anakin is freed in a podrace gambit and joins the group on their journey to Coruscant.
- **Darth Maul**, a Dathomirian Zabrak Sith apprentice, attacks. The Sith have returned for the first time in a millennium.
- Palpatine manipulates the Naboo crisis to be elected Supreme Chancellor of the Republic, replacing the ineffectual Chancellor Valorum.
- The Battle of Naboo: Anakin destroys the Trade Federation's droid control ship. Qui-Gon is killed by Maul. Obi-Wan defeats Maul (cutting him in half — though Maul survives, sustained by his hatred). Qui-Gon's dying wish is that Obi-Wan train Anakin.

**The Rise of the Separatists (32–22 BBY):**
- Over the next decade, a separatist movement grows in the Republic — worlds dissatisfied with corruption, taxation, and Coruscant's distant rule begin organizing to leave.
- The movement is led by **Count Dooku of Serenno**, a former Jedi Master who left the Order in disillusionment. He is secretly **Darth Tyranus**, Palpatine's new apprentice (Maul having been presumed dead).
- The Separatists form the **Confederacy of Independent Systems (CIS)**, a coalition backed by the Trade Federation, the Techno Union, the Banking Clan, and the Commerce Guild — all corporate interests with their own droid armies.
- Meanwhile, Jedi Master **Sifo-Dyas** secretly commissions a clone army from the Kaminoans (under manipulation by Dooku). Sifo-Dyas is murdered to keep the conspiracy hidden.

**The Outbreak of the Clone Wars / Attack of the Clones (22 BBY):**
- An assassination attempt on Senator Padmé Amidala draws Obi-Wan Kenobi into an investigation that leads him to Kamino, where he discovers the clone army.
- He tracks the bounty hunter **Jango Fett** (the clones' genetic template) to Geonosis, where the Separatists are massing for war.
- Anakin (now Padmé's protector) and Padmé travel to Geonosis to rescue Obi-Wan. They are captured and sentenced to execution in the Geonosian arena.
- **The Battle of Geonosis (22 BBY)** — The first battle of the Clone Wars. A Jedi rescue force arrives, then a clone army led by Yoda. Jango Fett is killed by Mace Windu. The Republic wins the battle but the war has begun. Dooku escapes after dueling Obi-Wan, Anakin, and Yoda.
- Anakin and Padmé secretly marry on Naboo at the end of the film.

**The Clone Wars (22 BBY – 19 BBY):**
A three-year galactic war that spans the entire saga's most prolific period of storytelling — covered in detail by *The Clone Wars* animated series, *Tales of the Jedi*, *The Bad Batch*, novels, and comics. Major events and arcs include:

- **The Battle of Christophsis and the meeting of Ahsoka Tano (22 BBY):** Yoda assigns Ahsoka Tano, a young Togruta Padawan, to Anakin Skywalker — much to his initial dismay. Their relationship becomes one of the emotional cores of the war.
- **The Battle of Teth and the rescue of Jabba's son (22 BBY):** Securing Hutt cooperation for Republic hyperspace lanes.
- **The Malevolence campaign:** Hunting General Grievous's ion-cannon-armed warship.
- **The Ryloth campaign:** Liberating Cham Syndulla's homeworld from Separatist occupation.
- **The Battle of Kamino:** The Separatists attempt to destroy the cloning facilities. Repulsed by clone defenders and Jedi.
- **The Geonosis re-invasion (21 BBY):** Reclaiming Geonosis from a Separatist resurgence. Discovery of the secret Death Star plans, suppressed by Palpatine.
- **The Mandalorian crisis:** Death Watch (led by Pre Vizsla) overthrows the pacifist Mandalorian government. Maul (resurrected and now leading a criminal empire) takes control of Mandalore, killing Vizsla with the Darksaber and being crowned the de facto ruler. Duchess Satine Kryze (Obi-Wan's lost love) is killed by Maul to torment Obi-Wan.
- **The Umbara campaign:** A traumatic operation under the unstable Jedi General Pong Krell, who turns out to be a fallen Jedi serving the Separatists. He manipulates the 501st into firing on their own brothers. Captain Rex's men ultimately execute Krell.
- **The Onderon campaign:** Ahsoka, Anakin, Obi-Wan, and Rex train resistance fighters (including future Rebellion leader **Saw Gerrera**) to liberate Onderon.
- **The discovery of the inhibitor chips:** Clone trooper Tup malfunctions and kills a Jedi prematurely. ARC trooper Fives investigates, uncovers the truth about the inhibitor chips and Order 66, and tries to warn the Republic. He is hunted down and killed by his fellow clones (Commander Fox) before he can expose the conspiracy.
- **Ahsoka's trial and departure from the Jedi Order (20 BBY):** Ahsoka is framed for a terrorist bombing at the Jedi Temple. The Council expels her, allowing the Republic to try her as a civilian. Anakin proves her innocence at the last moment, but the betrayal of the Council's faith causes Ahsoka to leave the Jedi Order — one of the most consequential moments in the war, and a major step in Anakin's own disillusionment.
- **The Siege of Mandalore (19 BBY):** Running concurrently with the events of *Revenge of the Sith*. Ahsoka returns to lead a Republic operation to capture Mandalore from Maul. She succeeds, with Rex and the 332nd Company. Maul is captured. Then Order 66 arrives.

**Revenge of the Sith (19 BBY):**
The climactic events that transform the galaxy:
- **The Battle of Coruscant:** The Separatists launch a massive surprise attack on the Republic capital. General Grievous kidnaps Chancellor Palpatine. Anakin and Obi-Wan lead a rescue mission. Anakin executes Count Dooku at Palpatine's urging — his first true step toward the dark side.
- **Anakin's visions of Padmé's death:** Anakin has prophetic dreams of Padmé dying in childbirth. He becomes desperate to save her.
- **Palpatine's seduction:** Palpatine reveals himself to Anakin as a Sith Lord and tells him the legend of Darth Plagueis — that the dark side can prevent death. Anakin is torn.
- **Mace Windu's attempted arrest:** Anakin reports Palpatine to Mace Windu, who leads a team of Jedi to arrest him. Palpatine slaughters them all except Windu. As Windu prepares to execute Palpatine, Anakin intervenes — cutting off Windu's hand. Palpatine then kills Windu with Force lightning and the Sith's takeover begins.
- **Anakin's fall:** Anakin pledges himself to Palpatine as **Darth Vader**. Palpatine sends him to the Jedi Temple to slaughter every Jedi inside — including the younglings.
- **Order 66 (19 BBY):** Palpatine issues Order 66 to every clone trooper in the galaxy. Across thousands of worlds, clones turn on their Jedi commanders and shoot them in the back. The Jedi Order — over 10,000 strong at the war's start — is effectively destroyed in a single day. Only a handful survive: Obi-Wan, Yoda, Ahsoka (no longer technically a Jedi), Cal Kestis, Cere Junda, Kanan Jarrus (then Caleb Dume), and others.
- **The declaration of the Empire:** Palpatine declares the Republic dissolved and proclaims the First Galactic Empire, with himself as Emperor. The Senate applauds.
- **The Mustafar duel:** Obi-Wan confronts Anakin/Vader on the volcanic world of Mustafar. Padmé, devastated by Anakin's fall, has followed him. In a fit of rage, Vader Force-chokes her. Obi-Wan and Vader duel — the most personally devastating fight in the saga. Obi-Wan defeats Vader, slicing off his legs and remaining arm. Anakin's body is consumed by lava and fire as he burns alive. Obi-Wan leaves him for dead.
- **Vader's resurrection:** Palpatine arrives, recovers Anakin's broken body, and has him reconstructed as the iconic armored, cybernetic Darth Vader — kept alive by life-support technology, breathing through a respirator, more machine than man.
- **The twins:** Padmé dies in childbirth after giving birth to twins — **Luke** and **Leia**. To hide them from Vader and the Emperor, they are separated: Leia is adopted by Senator Bail Organa and Queen Breha of Alderaan. Luke is sent to Tatooine to be raised by Anakin's stepbrother Owen Lars and his wife Beru. Obi-Wan goes into exile on Tatooine to watch over Luke. Yoda goes into exile on Dagobah.

---

### Era 5: The Reign of the Empire / Dark Times (19 BBY – 5 BBY)

**Overview:**
The first fifteen years of the Galactic Empire — sometimes called the **Dark Times**. The galaxy is under Imperial rule. The Jedi are hunted nearly to extinction. Resistance is scattered and uncoordinated. This era covers *Solo: A Star Wars Story*, *The Bad Batch*, *Obi-Wan Kenobi*, *Andor*, and *Star Wars: Rebels*.

**Key Events:**

**The Immediate Post-Order 66 Period (19 BBY – ~14 BBY):**
- The Empire consolidates power. The Senate is gradually stripped of authority but technically remains in existence as a rubber stamp.
- The **Inquisitorius** is established — an organization of dark-side warriors created to hunt the remaining Jedi. Many Inquisitors are fallen Jedi themselves, broken and turned by Vader. They include the **Grand Inquisitor**, the **Second Sister** (Trilla Suduri, the antagonist of *Jedi: Fallen Order*), the **Third Sister** (Reva Sevander, *Obi-Wan Kenobi*), the **Fifth Brother**, the **Seventh Sister**, the **Eighth Brother**, and the **Ninth Sister**.
- The Empire begins the secret construction of the **Death Star** at Geonosis, using Geonosian engineers (who are then exterminated to keep the secret). Galen Erso is forced to work on the project.
- The **Bad Batch** events: Clone Force 99 — Hunter, Wrecker, Tech, Crosshair, and Echo — flee Imperial service after refusing to massacre civilians. They become mercenaries and protectors of Omega, a young female clone. Their adventures explore the Empire's early consolidation, the phase-out of clones in favor of natural-born stormtroopers, and the Empire's secret experiments (including the Project Necromancer cloning research that would eventually result in Palpatine's resurrected body).

**The Tarkin Doctrine:**
- Grand Moff Wilhuff Tarkin formalizes the Empire's strategic doctrine: **rule through fear**. The Death Star is the ultimate expression — a weapon so terrifying no system would dare rebel.

**The Reorganization of the Senate (~18 BBY):**
- Palpatine dissolves regional governorships and replaces them with appointed Moffs answerable directly to him. Power becomes increasingly centralized.

**The Hunting of the Jedi (Ongoing):**
- The Jedi survivors live in hiding, suppressing their connection to the Force to avoid Inquisitor detection. Many are eventually found and killed. *Jedi: Fallen Order* (Cal Kestis) and *Jedi: Survivor* tell the story of one Jedi's survival.

**The Crimson Dawn Era / Solo (~10 BBY):**
- The events of *Solo: A Star Wars Story*. Han Solo escapes Corellia, joins the Empire, deserts, meets Chewbacca, Lando, and Tobias Beckett. He runs into the Crimson Dawn crime syndicate — secretly run by Maul (who survived being cut in half on Naboo) — and wins the Millennium Falcon from Lando in a sabacc game.

**Obi-Wan Kenobi (~9 BBY):**
- The events of the *Obi-Wan Kenobi* limited series. Obi-Wan, broken and in hiding on Tatooine, is forced out of exile when young Princess Leia is kidnapped. He reunites with Bail Organa, fights the Inquisitors (particularly Third Sister Reva, a Jedi survivor of Order 66 seeking revenge on Vader), and has a final confrontation with Vader — discovering Anakin is still alive within the suit. The two part not as friends or enemies but as wounded ghosts of who they once were.

**The Rise of Scattered Resistance (~5 BBY onward):**
- Bail Organa, Mon Mothma (Senator from Chandrila), and others quietly begin organizing political opposition.
- Independent resistance cells form across the galaxy — Saw Gerrera's Partisans (the most militant), the Lothal rebels, and others.

**Andor (5 BBY – 1 BBY):**
- The events of the *Andor* series. Cassian Andor's journey from cynical thief to dedicated rebel. The series provides the most ground-level, politically realistic look at how a rebellion against a totalitarian state actually forms — through propaganda, terror, prison labor, espionage, and the slow accumulation of small acts of defiance. The Aldhani heist, the Ferrix uprising, and the Mon Mothma political maneuvering establish the foundation of the Rebel Alliance.

**Star Wars: Rebels (5 BBY – 1 BBY):**
- The story of the **Ghost crew** — Hera Syndulla, Kanan Jarrus (a surviving Jedi), Sabine Wren (a Mandalorian), Zeb (a Lasat), Chopper (a droid), and **Ezra Bridger** (a young Force-sensitive boy who becomes Kanan's Padawan).
- They operate from the Outer Rim planet of Lothal. Over the series, they evolve from a small cell into a key Rebel unit, eventually merging with the larger Rebellion.
- Major events include: The introduction of Grand Admiral Thrawn as an Imperial antagonist; the return and final death of Darth Maul; Ahsoka Tano's appearance and her duel with Vader on Malachor (where she learns Anakin is still alive within Vader); the liberation of Lothal; and Ezra's disappearance into the Unknown Regions with Thrawn after a desperate gambit involving purrgil (space whales).

**Formation of the Rebel Alliance (~2 BBY):**
- The various rebel cells are formally united into the **Alliance to Restore the Republic** — the Rebel Alliance. Mon Mothma and Bail Organa are key founders. The Alliance establishes its first major base on Yavin 4.

---

### Era 6: The Age of Rebellion (5 BBY – 4 ABY)

**Overview:**
The era of the original trilogy. The Rebellion, formally organized, wages a desperate guerrilla war against the Empire. This is the saga's emotional and narrative climax — the redemption of Anakin Skywalker through his son Luke.

**Key Events:**

**Rogue One (0 BBY, immediately before *A New Hope*):**
- A small Rebel team led by Jyn Erso (daughter of Galen Erso, the Death Star's reluctant chief architect), Cassian Andor, K-2SO, Bodhi Rook, Baze Malbus, and Chirrut Îmwe steals the Death Star plans from the Imperial archive on **Scarif**.
- **The Battle of Scarif** is one of the most tactically brilliant engagements in the saga. The Rebel team breaches the planetary shield gate, infiltrates the data vault, and transmits the plans to Princess Leia's ship just as the Empire arrives. Every member of the ground team dies. Darth Vader personally pursues the transmission and is barely held off long enough for the plans to escape.
- The plans contain the Death Star's secret weakness: the thermal exhaust port that Galen Erso deliberately engineered as sabotage.

**A New Hope / Episode IV (0 BBY/ABY):**
- Princess Leia is captured by Vader while attempting to deliver the plans to Obi-Wan. She hides them in R2-D2 and dispatches him to find Obi-Wan on Tatooine.
- R2 and C-3PO escape to Tatooine, are sold to the Lars family, and are found by **Luke Skywalker** (now 19).
- Luke meets Obi-Wan ("Ben") Kenobi. Obi-Wan tells him about his father — Anakin Skywalker, a Jedi Knight (Obi-Wan omits the fall). He gives Luke Anakin's lightsaber.
- Luke's aunt and uncle are murdered by stormtroopers searching for the droids. Luke joins Obi-Wan.
- In **Mos Eisley**, they hire Han Solo and Chewbacca to fly them to Alderaan in the Millennium Falcon. They arrive to find Alderaan destroyed — the Death Star has been demonstrated. They're captured by the Death Star's tractor beam.
- Aboard the Death Star, they rescue Princess Leia. Obi-Wan duels Vader and allows himself to be killed, becoming one with the Force.
- **The Battle of Yavin (0 BBY/ABY):** The Rebels use the stolen plans to launch an attack on the Death Star. Luke, in his X-wing, fires the proton torpedo shot — guided by Obi-Wan's voice through the Force and his own dawning Force-sensitivity — that destroys the Death Star, saving the Rebel base on Yavin 4.

**Between A New Hope and Empire (0–3 ABY):**
- The Rebels evacuate Yavin 4 (knowing the Empire will retaliate) and relocate to Hoth.
- Vader hunts Luke obsessively across the galaxy.
- Various Star Wars stories (comics, the *Battlefront II* campaign, novels) cover this period.

**The Empire Strikes Back / Episode V (3 ABY):**
- The Empire discovers the Rebel base on **Hoth**. The **Battle of Hoth** — Imperial AT-ATs assault Echo Base. The Rebels evacuate as the base falls.
- Luke, on Obi-Wan's spectral instructions, travels to **Dagobah** to train with **Yoda**.
- Han, Leia, Chewbacca, and C-3PO flee to **Cloud City** on **Bespin**, run by Han's old friend **Lando Calrissian**. They are betrayed — Vader has arrived first and forced Lando into a trap.
- Han is frozen in carbonite and given to the bounty hunter **Boba Fett** to deliver to Jabba the Hutt.
- Luke abandons his training (against Yoda's warnings) to rescue his friends. He duels Vader in Cloud City's carbon-freezing chamber. Vader severs Luke's hand and reveals the most famous twist in cinema history: **"No. I am your father."** Luke chooses to fall rather than join Vader. He is rescued by Leia and Lando, fitted with a prosthetic hand, and the survivors regroup with the Rebel fleet.

**Between Empire and Jedi (3–4 ABY):**
- The Rebellion plans the rescue of Han Solo.
- Luke completes a new lightsaber (green, with a self-built crystal — or rather, with a personal kyber crystal). His training continues.

**Return of the Jedi / Episode VI (4 ABY):**
- Luke, Leia, Lando, Chewbacca, and the droids infiltrate Jabba's palace on Tatooine. After Leia's failed attempt as Boushh, Luke himself arrives. They escape over the Great Pit of Carkoon — Boba Fett is knocked into the Sarlacc. Han is rescued. Jabba's criminal empire is broken.
- Luke returns to Dagobah. Yoda confirms Vader is his father and dies, becoming one with the Force. The spirit of Obi-Wan reveals that Leia is Luke's twin sister.
- The Rebels learn the Empire is building a second Death Star at the forest moon of **Endor**. The Emperor is personally overseeing construction.
- The Rebel strategy: A strike team led by Han Solo and Leia infiltrates Endor's surface to destroy the shield generator protecting the Death Star. Simultaneously, the Rebel fleet (led by Admiral Ackbar) attacks the Death Star itself.
- On Endor, the Rebels are aided by the local **Ewoks**, who help defeat the Imperial garrison.
- Luke surrenders to Imperial forces, hoping to turn Vader back to the light. He is brought before the Emperor.
- **The Battle of Endor (4 ABY):** A three-front engagement.
  - In space, the Rebel fleet fights the Imperial fleet. They discover the Death Star's superlaser is operational and that they've been lured into a trap.
  - On the ground, the strike team is captured but freed by the Ewoks. The combined force destroys the shield generator.
  - In the Death Star's throne room, the Emperor tortures Luke with Force lightning to provoke Vader. When Luke is dying, **Anakin Skywalker turns against Palpatine** and throws him down the reactor shaft, sacrificing his own life in the process — fulfilling the prophecy of the Chosen One by destroying the last of the Sith.
  - Luke escapes with his father's body. Anakin appears as a Force ghost alongside Obi-Wan and Yoda at the Ewok celebration.
  - Lando and Wedge Antilles destroy the second Death Star's reactor, completing the battle.

The Empire is in chaos. The Rebellion celebrates across the galaxy.

---

### Era 7: The New Republic Era (5 ABY – 28 ABY)

**Overview:**
The Empire collapses in stages. The Rebellion reorganizes as the New Republic. Luke Skywalker attempts to rebuild the Jedi Order. This era covers *The Mandalorian*, *The Book of Boba Fett*, *Ahsoka*, and parts of *Andor*'s fallout. It is also covered by the *Aftermath* novel trilogy and several other works.

**Key Events:**

**The Imperial Collapse (4–5 ABY):**
- Without the Emperor, the Empire fragments. Various Imperial admirals and warlords seize regional power.
- Mas Amedda (Palpatine's chief vizier) becomes the Empire's nominal head but holds little real power.
- Rebel forces secure key worlds and push the remaining Imperial fleet back.

**The Battle of Jakku (5 ABY):**
- The decisive final battle of the Galactic Civil War. The remnants of the Imperial Navy make their last stand at Jakku. The Rebels — now the New Republic — win decisively. The desert of Jakku is covered with Star Destroyer wreckage (the famous wreck Rey explores in *The Force Awakens*).
- The Empire formally surrenders. The **Galactic Concordance** is signed, imposing harsh restrictions on the Empire (forced disarmament, war crimes tribunals, territorial restrictions).

**The Founding of the New Republic:**
- Mon Mothma becomes Chancellor of the New Republic. The capital is established on her homeworld of **Chandrila** initially, but the New Republic adopts a rotating capital system (to prevent another Coruscant-style concentration of power).
- The New Republic dramatically demilitarizes, believing peace is possible. Member worlds keep their own defense forces. This decision will prove catastrophic.

**The Imperial Remnants:**
- Various Imperial loyalists flee to the **Unknown Regions** in the galactic west — territory long charted by Imperial Grand Admiral **Thrawn** during his explorations.
- They begin secretly rebuilding under a long-term plan called **Project Necromancer** (the secret cloning project to resurrect Palpatine) and **Project Sledgehammer** (military reconstruction). This shadow Empire will eventually become the First Order.

**The Mandalorian Era (~9 ABY):**
The events of *The Mandalorian*, *The Book of Boba Fett*, *Ahsoka*, and *Skeleton Crew* take place in this period.

- **Din Djarin (the Mandalorian)** and **Grogu** (the young Force-sensitive child known initially as "the Child" or by fans as "Baby Yoda"): A bounty hunter and his charge become unlikely family. Grogu was a youngling at the Jedi Temple during Order 66 and was rescued. He's the same species as Yoda, ages slowly, and is approximately 50 years old during *The Mandalorian* despite appearing as a toddler.
- **The retaking of Mandalore:** Din Djarin and Bo-Katan Kryze lead an effort to reclaim Mandalore (which the Empire devastated in the "Night of a Thousand Tears" purge during the late Imperial era). The Mandalorian sects unite.
- **Boba Fett's resurrection:** Having escaped the Sarlacc, Boba Fett recovers his armor and takes control of Jabba's former criminal empire on Tatooine.
- **The return of Grand Admiral Thrawn:** In *Ahsoka*, Thrawn returns from his exile in the Unknown Regions, having been stranded there with Ezra Bridger after *Rebels*. His return is the catalyst for many of the events that will eventually lead to the First Order's emergence.
- **Ahsoka Tano:** Continues her journey — training Sabine Wren as her apprentice, hunting Thrawn, and meeting Anakin as a Force ghost during a near-death experience.
- **The Imperial cloning facilities:** Doctor Pershing and others continue clandestine research into transferring consciousness — work that will eventually enable Palpatine's resurrection.

**Luke Skywalker's Jedi Academy (~11–28 ABY):**
- Luke founds a new Jedi Order, training Force-sensitive students at a temple on Ossus (Legends) or various locations (canon — the exact location varies in sources).
- Among his students is his nephew, **Ben Solo** (son of Han and Leia, born around 5 ABY).
- Ben Solo is gradually corrupted by **Snoke**, a mysterious dark-side figure (later revealed to be a puppet/clone created by the resurrected Palpatine).
- Around 28 ABY, the **Destruction of Luke's Jedi Temple**: Luke, sensing the dark side overwhelming Ben, has a moment of weakness in which he briefly considers killing his nephew in his sleep. Ben wakes, perceives the betrayal, and in fury destroys the temple, kills several students, and turns to the dark side, becoming **Kylo Ren** and the leader of the **Knights of Ren**.
- Luke, devastated by his failure, goes into self-imposed exile on **Ach-To** — the location of the first Jedi Temple.

---

### Era 8: The Rise of the First Order (28 ABY – 34 ABY)

**Overview:**
The First Order, secretly built up over decades in the Unknown Regions, emerges as a major galactic power. The New Republic, complacent and demilitarized, refuses to take the threat seriously. General Leia Organa founds the **Resistance** as an unofficial paramilitary force to fight back. This sets the stage for the sequel trilogy.

**Key Events:**

**The Founding of the Resistance (~28 ABY):**
- Leia, frustrated with the New Republic Senate's refusal to act against the First Order, founds the Resistance with a small group of military veterans, sympathetic systems, and private donors.
- The Resistance operates from secret bases (eventually D'Qar) and includes veterans of the Rebellion (Ackbar, Statura) and a new generation of pilots and operatives (Poe Dameron, Snap Wexley, Karé Kun).

**The Search for Luke Skywalker:**
- Luke's location is unknown. Both the First Order and the Resistance seek him. A map to his location is fragmented and held in various places.

---

### Era 9: The Sequel Trilogy / The Last War (34 ABY – 35 ABY)

**The Force Awakens / Episode VII (34 ABY):**
- The First Order, led by **Supreme Leader Snoke** and his military commander **General Hux**, hunts the map to Luke Skywalker.
- On Jakku, Resistance pilot **Poe Dameron** is captured. He hides the map in his droid **BB-8**.
- **Finn (FN-2187)**, a First Order stormtrooper, defects after witnessing a massacre on Jakku. He escapes with Poe.
- **Rey**, a scavenger on Jakku, finds BB-8 and is drawn into the conflict.
- Han Solo and Chewbacca find them in the Millennium Falcon. Han has separated from Leia after the loss of their son.
- **The First Order destroys the Hosnian system with Starkiller Base**, annihilating the New Republic's capital and government in a single shot. Five planets vaporized. The New Republic effectively ceases to exist.
- At the Resistance base, Han confronts his son **Kylo Ren** on Starkiller Base. Kylo murders his father.
- Poe leads a strike on Starkiller Base, destroying it.
- Rey, having shown unprecedented Force abilities, finds Luke on Ahch-To.

**The Last Jedi / Episode VIII (34 ABY):**
- Luke, broken by his failure with Ben, refuses to train Rey.
- The First Order pursues the fleeing Resistance fleet. Many Resistance ships are destroyed.
- Rey and Kylo Ren share a unique Force connection — they can see, speak to, and touch each other across vast distances. This is later revealed to be a **Force dyad**, an extraordinarily rare bond.
- Rey believes she can turn Kylo back. She travels to Snoke's flagship. Kylo kills Snoke and offers Rey a place at his side ruling the galaxy together — she refuses.
- **Vice Admiral Holdo's hyperspace ram:** With the Resistance fleet nearly destroyed, Holdo turns her cruiser around and jumps to lightspeed *through* the First Order flagship, the *Supremacy* — one of the most visually stunning moments in cinema. This destroys most of the First Order fleet pursuing them.
- The Resistance lands on **Crait**, an old Rebel base. The First Order assaults with AT-M6 walkers.
- **Luke's last stand:** Luke projects himself across the galaxy via the Force to confront Kylo Ren and buy the Resistance time to escape. After confronting Kylo, Luke becomes one with the Force on Ahch-To.
- The Resistance escapes on the Falcon. They are a tiny, scattered remnant. But the legend of Luke's return inspires galaxy-wide hope.

**The Rise of Skywalker / Episode IX (35 ABY):**
- Kylo Ren discovers that **Emperor Palpatine has returned**, alive on the hidden Sith world of **Exegol**, having transferred his consciousness into a cloned body (the secret of Plagueis, finally realized — but imperfectly, as the body is failing).
- Palpatine reveals he has built the **Final Order** — thousands of Xyston-class Star Destroyers, each armed with a planet-killing superlaser. He intends to unleash them on the galaxy.
- **Rey discovers her true identity:** She is Palpatine's granddaughter. Her parents hid her on Jakku to keep her safe from Palpatine's hunters. They were killed for it.
- The Resistance races to find Exegol. With help from Lando Calrissian and intelligence from a defector, they assemble for a final battle.
- **The Battle of Exegol:** The Resistance fleet engages the Final Order. They cannot win alone — but Lando arrives leading a massive citizens' fleet, drawn from every system in the galaxy, finally rising up against tyranny.
- **The throne room confrontation:** Rey and Ben Solo (now redeemed by the memory of his father Han) confront Palpatine together. Palpatine drains their dyad energy to restore himself but is overwhelmed by Rey channeling the strength of every Jedi who came before. He is destroyed.
- **Ben's sacrifice:** Rey dies in the battle. Ben gives his life to revive her through Force healing. He becomes one with the Force.
- The Final Order is destroyed. The First Order collapses. The galaxy celebrates.
- Rey travels to Tatooine, to the old Lars homestead. She buries Luke and Leia's lightsabers in the sand. A passerby asks her name. She looks up at the twin suns and answers: **"Rey. Rey Skywalker."**

---

### Era 10: The New Jedi Order / Post-Saga Era (35 ABY onward)

**Overview:**
This era is largely unexplored in current canon — it represents the future of the saga. Some tie-in material and the announced *Rey* film (Daisy Ridley returning) will explore this period.

**What We Know:**
- Rey is rebuilding the Jedi Order in a new form, learning from the failures of the past.
- The galaxy is rebuilding from generations of war.
- The Force, as ever, continues to seek balance.

**In Legends (non-canonical):**
- The Yuuzhan Vong War (an extragalactic invasion that devastated the New Republic and killed many beloved characters including Chewbacca and Anakin Solo).
- Jacen Solo's fall to the dark side as Darth Caedus.
- The Legacy era (~130 ABY) featuring Cade Skywalker, Luke's descendant.
- The Sith eternal threat in various forms.

The future of canonical Star Wars storytelling in this era is one of the most anticipated developments in the franchise.

---

## Part III: Key Themes Across the Eras

Several themes weave through every era of Star Wars:

**The Cyclical Nature of Conflict:** The Sith fall and rise, the Republic forms and collapses, peace gives way to war and back again. The galaxy never reaches lasting stability — and Star Wars suggests that perhaps no large civilization can.

**The Corruption of Power:** Whether it's the bureaucratic decay of the Old Republic, Palpatine's seduction of the Senate, the militarization of the Empire, or the New Republic's complacency — political institutions repeatedly fail through internal rot rather than external attack.

**The Tension Between Attachment and Selflessness:** The Jedi's prohibition on attachment was meant to prevent fear and corruption — but it created emotional repression that contributed to Anakin's fall. Luke's love for his father saved the galaxy. The proper relationship between love and duty is one of the saga's deepest unresolved questions.

**Hope as a Weapon:** The Rebellion's greatest asset was always hope — "Rebellions are built on hope" (Jyn Erso). Even in the darkest moments, hope endures and inspires action.

**Identity is a Choice:** Anakin chose darkness, then chose light. Luke chose to believe in his father when no one else would. Rey, a Palpatine, chose to be a Skywalker. Ben Solo, who fell so far, chose redemption. Across every era, the saga affirms that no one is defined by blood, origin, or past — only by what they choose to become.

---

*"This is the way."*
